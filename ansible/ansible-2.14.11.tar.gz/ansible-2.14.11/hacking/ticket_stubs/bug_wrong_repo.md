Hi!

Thanks very much for your interest in Ansible.  It means a lot to us.

This appears to be something that should be filed against another project or bug tracker. Here's why:

   * FILL IN

<< CHOOSE AS APPROPRIATE >>

   * https://github.com/ansible-community/ansible-lint
   * https://github.com/ansible/ansible-runner
   * https://github.com/ansible/ansible-navigator
   * https://github.com/ansible-community/antsibull
   * https://github.com/ansible-community/ara
   * https://github.com/ansible/awx
   * https://github.com/ansible-collections/community.general
   * https://github.com/ansible-community/molecule
   * For AAP or Tower licensees report issues via your Red Hat representative or https://issues.redhat.com 

If you can stop by the tracker or forum for one of those projects, we'd appreciate it.

Because this project is very active, we're unlikely to see comments made on closed tickets and we lock them after some time.
Should you still wish to discuss things further, or if you disagree with our thought process, please stop by one of our two mailing lists:

   * https://groups.google.com/forum/#!forum/ansible-devel
   * Matrix: [#devel:ansible.im](https://matrix.to/#/#devel:ansible.im)
   * IRC: #ansible-devel on [irc.libera.chat](https://libera.chat/)

We'd be happy to discuss things.

See  this page for a complete list of communication channels and their purposes:

   * https://docs.ansible.com/ansible/latest/community/communication.html

Thank you once again!


