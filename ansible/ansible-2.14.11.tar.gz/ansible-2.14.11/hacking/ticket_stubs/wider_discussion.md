Hi!

Thanks very much for your submission to Ansible.  It means a lot to us.

We are interested in this idea and would like to see a wider discussion on it on one of our lists.
Reasons for this include:

   * INSERT REASONS!

Because this project is very active, we're unlikely to see comments made on closed tickets and we lock them after some time.
Can you please post on ansible-development list so we can talk about this idea with the wider group?

   * https://groups.google.com/forum/#!forum/ansible-devel
   * Matrix: [#devel:ansible.im](https://matrix.to/#/#devel:ansible.im)
   * #ansible-devel on [irc.libera.chat](https://libera.chat/)

Or bring up in one of the weekly Matrix/IRC meetings with the core group:

   * https://github.com/ansible/community/issues?q=is:open+label:meeting_agenda+label:core

For other alternatives, check this page for a more complete list of communication channels and their purposes:

   * https://docs.ansible.com/ansible/latest/community/communication.html

Thank you once again for this and your interest in Ansible!

