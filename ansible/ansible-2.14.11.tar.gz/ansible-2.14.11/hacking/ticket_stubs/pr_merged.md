Hi!

This has been merged in, and will also be included in the next major release.
For more info on our process see https://docs.ansible.com/ansible/devel/reference_appendices/release_and_maintenance.html#ansible-core-workflow

If you or anyone else has any further questions, please let us know by stopping by one of the mailing lists or chat channels, as appropriate.

Because this project is very active, we're unlikely to see comments made on closed tickets and we lock them after some time.
The mailing list and irc are great ways to ask questions, or post if you don't think this particular issue is resolved.

See  this page for a complete and up to date list of communication channels and their purposes:

   * https://docs.ansible.com/ansible/latest/community/communication.html

Thank you!
