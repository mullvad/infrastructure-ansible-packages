Hi!

We have ascertained that the following PR/commits should resolve this question or problem for you.

<< INSERT SHA/PR LINK HERE >>

This should be included newer releases starting with << RELEASE/the next [major] release(s) >>.

Because this project is very active, we're unlikely to see comments made on closed tickets and we lock them after some time.
The mailing list and irc are great ways to ask questions, or post if you don't think this particular issue is resolved.

See  this page for a complete list of communication channels and their purposes:

* https://docs.ansible.com/ansible/latest/community/communication.html

Thank you!
