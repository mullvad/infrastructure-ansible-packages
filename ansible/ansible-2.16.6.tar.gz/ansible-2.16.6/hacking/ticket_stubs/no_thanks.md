Hi!

Thanks very much for your submission to Ansible.  It means a lot to us that you've taken time to contribute.

Unfortunately, we're not sure if we want this feature in the program, and I don't want this to seem confrontational.
Our reasons for this are:

* (A) INSERT ITEM HERE

However, we're absolutely always up for discussion.
Because this project is very active, we're unlikely to see comments made on closed tickets and we lock them after some time.
If you or anyone else has any further questions, please let us know by using any of the communication methods listed in the page below:

* https://docs.ansible.com/ansible/latest/community/communication.html

In the future, sometimes starting a discussion on the development list prior to implementing a feature can make getting things included a little easier, but it's not always necessary.

Thank you once again for this and your interest in Ansible!
