symlinks
========

Symbolic links are only permitted for files that exist to ensure proper tarball generation during a release.

If other types of symlinks are needed for tests they must be created as part of the test.
